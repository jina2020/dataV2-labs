![Ironhack logo](https://i.imgur.com/1QgrNNw.png)

# Lab | Goodness of Fit and Independence Tests

Go through the main.ipynb and complete the questions.
